module.exports = {
  user: "BED_ASSG",
  password: "123456",
  server: "localhost",
  database: "BED_ASSG",
  trustServerCertificate: true,
  options: {
    port: 1433,
    connectionTimeout: 60000,
  },
};